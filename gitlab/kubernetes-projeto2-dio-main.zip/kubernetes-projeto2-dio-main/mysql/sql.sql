CREATE TABLE mensagens (
    id int,
    nome varchar(50),
    mensagem varchar(100)
);